
<?php 
if(filter_input(INPUT_SERVER,'REQUEST_METHOD')==='POST'){
        $list = array();
        $listStr = filter_input(INPUT_POST, 'list');
        if (!empty($listStr)){
            $list = json_decode($listStr,TRUE);
            
        }
        $title = filter_input(INPUT_POST,'title');
        if (!empty($title)){
            $author = filter_input(INPUT_POST, 'author');
            $price = filter_input(INPUT_POST, 'price');
            $book =array();
            $book['title']=$title;
            $book['author']=$author;
            $book['price']=$price;

            
            $list []= $book;
            
            }
            if (count($list)>0){
                $listStr = json_encode($list);
                
            }
}    
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Book Inventory</title>
        <style>
            table, th, td {
                border: 1px solid black;
            }
        </style>    
    </head>
    <body>
        <form action="books.php" method="POST">
            Title: <input type="text" name="title" /><br>
            Author: <input type="text" name="author" /><br>
            Price: <input type="text" name="price" /><br>
            <input type="hidden" name="list" value='<?php  if(!empty ($listStr))echo $listStr ;?>' /><br>
            <input type="submit" name="action" value="Add To List"/><br> 
        </form>
        <hr>
        <?php
        if (!empty($listStr)){
            echo "you have enterd the following books:<br>";
        echo $listStr.'<br>';}
        
        ?>
    </body>
</html> 