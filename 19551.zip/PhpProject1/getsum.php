
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

<?php
    if(filter_input(INPUT_SERVER,'REQUEST_METHOD')==='POST'){
        $list = array();
        $listStr = filter_input(INPUT_POST, 'list');
        if (!empty($listStr)){
            $list = explode(',', $listStr);
            
        }
        $number = filter_input(INPUT_POST, 'number');
        if (!empty($number)){
            $list[] = $number;
        }
        
        if (count($list)>0){
            $listStr = implode(',', $list);
            
        }
                
    }

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Numbers</title>
    </head>
    <body>
        <form action = "getsum.php" method="POST">
            Enter Number: 
            <input type="text" name="number" /><br>
            <input type="hidden" name="list" value="<?php  if(!empty ($listStr))echo $listStr ;?>" /><br>
            <input type="submit" name="action" value="Add To List"/><br> 
        </form>
        <hr>
        <form action="sum.php" method="POST">
            <input type="hidden" name="list" value="<?php  if(!empty ($listStr))echo $listStr ;?>" /><br>
            <input type="submit" value="Get Sum"/><br> 
        </form>
        <form action="product.php" method="POST">
            <input type="hidden" name="list" value="<?php  if(!empty ($listStr))echo $listStr ;?>" /><br>
            <input type="submit" value="Get Product"/><br> 
        </form>
        <hr>
        <?php
        if(!empty ($listStr)){
            echo"You've entered these numbers:<br>";
            echo $listStr.'<br>';
            
        }
        if (isset($sum)){
            echo 'The sum is $sum<br>';
        }
        
        if (isset($product)){
           echo 'The multi is $product<br>';
        }
        ?>
        
    </body>
</html>