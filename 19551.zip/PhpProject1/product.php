<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$list =[];
$listStr = filter_input(INPUT_POSTT,'list');
if (!empty($listStr)){
    $list = explode(',', $listStr);
}
$product=1;
foreach ($list as $num){
    $product*=$num;
}
include 'product.php';
    