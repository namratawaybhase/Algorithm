<?php echo anchor('shop/index', 'Continue Shopping') ; ?>

<?php echo form_open('shop/display_order'); ?>
<select name="order">
    <?php foreach ($order_query->result() as $order_row) : ?>
        <option value="<?php echo $order_row->order_id; ?>">
            <?php echo "Order: ",$order_row->order_id; ?>
            <?php echo date('-m/d/y H:i:s',$order_row->order_created_at); ?>
        </option>
    <?php endforeach; ?>
</select>
<?php echo form_submit('', 'Search'); ?>
<?php echo form_close(); ?>
<?php echo form_open('shop/process_order'); ?>
<?php 
echo '<h3>Customer ID: '.$cust_details['cust_id'].'</h3>';
echo '<h3>First Name: '.$cust_details['cust_first_name'].'</h3>';
echo '<h3>Last Name: '.$cust_details['cust_last_name'].'</h3>';
echo '<h3>Address: '.$cust_details['cust_address'].'</h3>';
?>
<table cellpadding="6" cellspacing="1"
       style="width:50%" border="1">
    <tr>
        <th>Quantity</th>
        <th>Description</th>
        <th>Item Price</th>
        <th>Sub-Total</th>
    </tr>
    <?php $i = 1;
    $total= 0;?>
    <?php foreach ($order_details as $items): ?>
        <?php
        echo form_hidden($i . '[rowid]', $items['rowid']);
        ?>
        <tr>
            <td><?php
                echo number_format($items['qty']);
                ?>
            </td>
            <td>
                <?php echo $items['name']; ?>
            </td>>
            <td>
                <?php
                    echo number_format($items['price'],2);
                ?>
            </td>
            <td>$
                <?php echo number_format($items['qty']*$items['price'],2);
                    $total+=$items['qty']*$items['price'];
                ?>
            </td>
        </tr>
        <?php $i++; ?>
    <?php endforeach;?>
                 
    <tr>
        <td colspan="2"> </td>
        <td><strong>Total</strong></td>
        <td>$<?php
            echo number_format($total,2);
            ?></td>
    </tr>
</table>
<p><?php echo form_submit('', 'Process Order'); ?></p>
<?php echo form_close(); ?>
