<?php echo anchor('shop/process_order','Process Order');?><br>
<?php echo form_open('shop/process_order'); ?>

    <html>
        <body>
            <h1><?php echo"Order has been placed successfully "?></h1>
        </body>>
    </html>     
    
<?php echo form_close(); ?>
