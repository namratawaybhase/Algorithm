<body>
    <?php echo validation_errors(); ?>
    <?php echo form_open('/cust/user_details'); ?>
    <label> First Name <?php
        echo form_input(array('name' => 'first_name',
            'value' => '', 'maxlength' => '125',
            'size' => '50'));
        ?><br /></label>
    <label> Last Name  
        <?php
        echo form_input(array('name' => 'last_name',
            'value' => '', 'maxlength' => '125',
            'size' => '50'));
        ?><br/>
    </label>
    <label>Email Address
        <?php
        echo form_input(array('name' => 'email',
            'value' => '', 'maxlength' => '255',
            'size' => '50'));
        ?><br/>
    </label>
    <label>Confirm Email
        <?php
        echo form_input(array('name' =>
            'email_confirm', 'value' => '',
            'maxlength' => '255', 'size' => '50'));
        ?>
        <br/>
    </label>
    <label>Payment Address<br>
        <?php
        echo form_textarea(array('name' =>
            'payment_address', 'value' => '',
            'rows' => '6', 'cols' => '40',
            'size' => '50'));
        ?><br/>
    </label>
    <?php echo form_submit('', 'Enter'); ?><br/>
    <?php echo form_close(); ?>
</form>
</body>