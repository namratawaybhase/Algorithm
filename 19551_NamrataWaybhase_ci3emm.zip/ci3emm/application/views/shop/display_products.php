<?php echo anchor('shop/display_cart','Go to Cart'); ?><br>
<?php echo anchor('shop/display_order','Go to Order');?><br>

<?php echo form_open('shop/index');?>

<select name="cat">
    <option value="0" <?php if($cat === 0) echo 'selected'; ?>>All</option>
    <?php foreach ($cat_query->result() as $cat_row) : ?>
        <option value="<?php echo $cat_row->cat_id; ?>" <?php if($cat == $cat_row->cat_id) echo 'selected'; ?>>
            <?php echo $cat_row->cat_name; ?>
        </option>
    <?php endforeach; ?>
</select>
<?php echo form_submit('', 'Search'); ?>
<?php echo form_close(); ?>

<body>
    <table>
        <?php foreach ($query->result() as $row) : ?>
            <tr>
                <td><?php echo $row->product_id; ?></td>
                <td><?php echo $row->product_name; ?></td>
                <td><?php echo $row->product_description; ?></td>
                <td><?php echo anchor('shop/add/' . $row->product_id, 'Add to cart');
            ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
