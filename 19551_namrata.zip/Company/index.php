<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <style>
        table{   
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }

        tr:nth-child(even) {
          background-color: #dddddd;
        }
            
        </style>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        

        $company = ['Department'=>
            ['Enginerring'=>['Group'=>
                ['Hardware'=>[['Employee'=>'Tom','Project'=>'A','Salary'=>5000],
                              ['Employee'=>'Jim','Project'=>'B','Salary'=>6000]],
                 'Software'=>[['Employee'=>'Peter','Project'=>'A','Salary'=>5000],
                              ['Employee'=>'Lily','Project'=>'A','Salary'=>3000],
                              ['Employee'=>'Nancy','Project'=>'B','Salary'=>4500]]
                ]
            ],
            'Marketing'=>['Group'=>['America'=> [['Employee'=>'Carl','Project'=>'A','Salary'=>6000],
                                                 ['Employee'=>'Dave','Project'=>'A','Salary'=>7500]],
                                    'Asia'=>[['Employee'=>'Ping','Project'=>'B','Salary'=>4500]]
                                    ]
                        ]]
          
        ];
        
        function getEmployeesByProject($company){
            $result_A = array();
            $result_B = array();
            $result = array();
            foreach ($company as $key =>$value){
                foreach ($value as $dept_key=>$dept_value){
                    foreach ($dept_value as $group_key =>$group_value){
                        foreach ($group_value as $hardware_key =>$hardware_value){
                            foreach ($hardware_value as $emp_key=>$emp_value){
                                if ($emp_value['Project']=='A'){
                                    array_push($result_A,$emp_value['Employee']);
                                    #$result['A']=$emp_value['Employee']; 
                                }
                                if ($emp_value['Project']=='B'){
                                    array_push($result_B,$emp_value['Employee']);
                                }
                            }
                        }
                    }
                }
            }
        
            $result['A']=$result_A;
            $result['B']=$result_B;

            return ($result);
            
        }
        function getHighSalaryEmployeeByDept($company){
            $result=[];
            $max_eng=0;
            $max_mkt=0;
            foreach ($company as $key =>$value){
                foreach ($value as $dept_key=>$dept_value){
                    foreach ($dept_value as $group_key =>$group_value){
                        foreach ($group_value as $hardware_key =>$hardware_value){
                            foreach ($hardware_value as $emp_key=>$emp_value){
                                if ($emp_value['Salary']>$max_eng and $dept_key == 'Enginerring'){
                                    $max_eng = $emp_value['Salary'];
                                array_push($result,$max_eng);
                                    #$result['A']=$emp_value['Employee'];
                                
                                }
                                if ($emp_value['Salary']>$max_mkt and $dept_key=='Marketing'){
                                    $max_mkt = $emp_value['Salary'];
                                    
                                array_push($result,$max_mkt);
                                }
                            }
                        }
                    }
                }
            }
        $result['Engineering'] = $max_eng;
        $result['Marketing'] = $max_mkt;
        return $result;
        
        }
        function printStore($company){
            echo '<table border="1">';
            echo '<tr><th>Department</th><th>Group</th><th>Employee</th><th>Project</th><th>Salary</th></tr>';

            foreach ($company as $key =>$value){
               echo "<tr>";
                foreach ($value as $dept_key=>$dept_value){
                   // echo '<td>' .$dept_key. '</td>';
                   
                    foreach ($dept_value as $group_key =>$group_value){
               
                        foreach ($group_value as $hardware_key =>$hardware_value){
                             //echo '<td>' .$hardware_key. '</td>';
                            foreach ($hardware_value as $emp_key=>$emp_value){
                                echo '<td>' .$dept_key. '</td>';
                                echo '<td>' .$hardware_key. '</td>';
                                echo '<td>' . $emp_value['Employee'] .'</td>';
                                echo '<td>' . $emp_value['Project'] .'</td>';
                                echo '<td>' . $emp_value['Salary'] .'</td>'; 
                                echo'</tr>';
                                };
                            }
                        }
                    }
                }
            }
            echo'</table>';
        
        var_dump(getEmployeesByProject($company));
        var_dump(getHighSalaryEmployeeByDept($company));
        var_dump(printStore($company));
        // put your code here
       
        
    ?>
  
    </body>
</html>
      
             
             
         