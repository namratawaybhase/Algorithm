
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Personal Information</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <h1>Personal Information</h1>
        <form action="index.php" method="POST">
            Name: <input type="text" name="name" value="" /><br>
            Age: <input type="text" name="age" value=""/><br>
            Email Address: <input type="text" name="email" value="" /><br>
            <input type="submit" name="nextButton" value="Page2"/><br> 
        </form>
        <hr>
        <h3> <?php echo $errStr; ?> </h3>
            </body>
</html>
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

