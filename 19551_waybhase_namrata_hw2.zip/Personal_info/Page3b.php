
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Graduate Degree Programs</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <h1>Graduate Degree Programs</h1>
        <form action="index.php" method="POST">
            Select your program(s): <br>
            <input id='mscs' type="checkbox" name="programs[]" value="MSCS" >MSCS<br>
            <input id='mba' type="checkbox" name="programs[]" value="MBA" >MBA<br>

            <input type="hidden" name="applicantStr" value='<?php if (!empty($appStr)) echo $appStr; ?>' /><br>
            <input type="submit" name="prevButton" value="Page2"/>
            <input type="submit" name="nextButton" value="Page4"/> <br>
        </form>
        <hr>
        <h3> <?php echo $errStr; ?> </h3>
            </body>
</html>

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

