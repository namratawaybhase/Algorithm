<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Final Page</title>
        <style>
            table, th, td {
                border: 1px solid black;
            }
        </style>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <h1>Final Page</h1>
        <form action="index.php" method="POST">
            You have entered the following information: <br>
            <table>
                <tr>
                    <th>Field</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><?php echo $list['name'] ?></td>
                </tr>
                <tr>
                    <td>Age</td>
                    <td><?php echo $list['age'] ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo $list['email'] ?></td>
                </tr>
                <tr>
                    <td>Degree Level</td>
                    <td><?php echo $list['level'] ?></td>
                </tr>
                <tr>
                    <td>Programs</td>
                    <td><?php echo $list['programs'] ?></td>
                </tr>
            </table>
            <input type="hidden" name="applicantStr" value='<?php if (!empty($appStr)) echo $appStr; ?>' /><br>
            <input type="submit" name="prevButton" value="Page3"/>
            <input type="submit" name="nextButton" value="Reset"/><br> 
        </form>
    </body>
</html>




