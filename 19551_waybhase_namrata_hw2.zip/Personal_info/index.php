<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $list = array();
        $programs=array();
        $nameErr = $ageErr= $emailErr ='';
        // put your code here
        if (filter_input(INPUT_SERVER, 'REQUEST_METHOD') === 'POST') {
            
            $appStr= filter_input(INPUT_POST, 'applicantStr');
            $name = filter_input(INPUT_POST, 'name');
            $age = filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT);
            $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
            $level=filter_input(INPUT_POST,'level');
            //$programs = filter_input_array(INPUT_POST, 'programs');
            if(isset($_POST['programs'])){
                $programs = $_POST['programs'];
            }
            
            if (isset($_POST['nextButton'])) {
                $nextPage = $_POST['nextButton'];
                switch ($nextPage) {
                    case 'Page2':
                        $list['name'] = $name;
                        $list['age'] = $age;
                        $list['email'] = $email;
                        $appStr = json_encode($list);
                        if (!$email) {
                            $errStr = "The email address field is invalid.";
                       
                        }
                        if (!$name){
                            $errStr = "The name field should not be empty";
                        }
                        if (!$age || is_int(!$age)){
                            $errStr="The age field should not be empty and must be an integer.";
                        }
                        if (!empty($errStr)){
                            include 'Page1.php';
                        }
                        else {
                            include 'Page2.php';
                        }
                        break;
                    case 'Page3':
                        $list = json_decode($appStr, true);
                        $list['level'] = $level;
                        $appStr = json_encode($list);
                        if (!$level) {
                            $errStr = "You must select a degree level.";
                            include 'Page2.php';
                        } else {
                            if ($level=='undergraduate'){
                                include 'Page3.php';
                            } else {
                                include 'Page3b.php';
                            }
                        }
                        break;
                    case 'Page4':
                        $list = json_decode($appStr, true);
                        $pstr = implode(',', $programs);
                        $list['programs'] = $pstr;
                        $appStr = json_encode($list);
                        if (!$programs){
                            $errStr = "You must select at least one program.";
                            if ($list['level']=='undergraduate'){
                                include 'Page3.php';
                            }else {
                                include 'Page3b.php';
                            }
                            
                        } else {
                            include 'Page4.php';

                        }
                        
                        break;
                    case 'Reset':
                        unset($appStr);
                        break;
                }
            } else {
                $prevPage = $_POST['prevButton'];
                switch ($prevPage) {
                    case 'Page1': 
                        include 'Page1.php';
                        break;
                    case 'Page2':
                        include 'Page2.php';
                        break;
                    case 'Page3':
                        $list = json_decode($appStr, true);

                        if ($list['level'] == 'undergraduate') {
                            include 'Page3.php';
                        } else {
                            include 'Page3b.php';
                        }
                        break;
                }
            }
        }
            
        if (empty($appStr)) {
            include 'Page1.php';
        }    
            
            
            
            
            
            
            /*
            
            
            
            if (!empty($name)){
                $list['name']=$name;   
            }
            
            if (!empty($age)){
                $list['age']=$age;
                
            }             
            if (!empty($email)){
                $list['email']=$email;
            }
            if (!empty($listStr)) {
                $list = explode(',', $listStr);
            }
            if (!empty($level)){
                $list['level']= $level;
            }
            if (!empty($programs)){
                
                foreach ($programs as $check) {
                    echo $check;
                }
            }
            

        }
      
        if (!empty($action)){
            switch ($action){
                case 'savePersonalData':
                    $viewdata='This is view data Namrata';
                    $appStr= implode(',', $list);
                    include 'Page2.php';
                    break;
                case 'saveLevel':
                   
                    $appStr= implode(',', $list);
                    if ($level=='undergraduate'){
                        include 'Page3.php';
                    }else
                        include 'Page3b.php';
                    break;
                    
                case 'savePrograms':
                    $appStr = implode(',', $list);
                    $final=$list;
                    include 'Page4.php';
                    break;
                
                case 'Reset':
                    include 'Page1.php';
                    break;
                
                case 'Page1':
                    include 'Page1.php';
                    break;
            
                
                case 'Page2':

                    include 'Page2.php';
                    break;
                
                case 'Page3':
                    include 'Page3.php';
                    break;
            }
       
        } else {
            include 'Page1.php';
               
        } */
        ?>
    </body>
</html>
