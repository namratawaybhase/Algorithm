<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>My Bookstore</title>
        <link rel="stylesheet" type="text/css" href="style2.css" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div class="header">
            <h1>My Bookstore</h1>
        </div>
        <div class="row">
            <div class="column-left">
                <h1>Main Menu</h1>
                <p><a href = "manage_book">Managing Books</a></p>
                <p><a href = "search_book">Searching Books</a></p>
            </div>
            <div class="column-right">
                <h1>Home Page</h1>
                <p>This is the home page.</p>
            </div>
        </div>
    </body>
</html>
