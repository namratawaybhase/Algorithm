<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>My Bookstore</title>
        <link rel="stylesheet" type="text/css" href="../style2.css" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div class="header">
            <h1>Managing Your Book</h1>
        </div>
        <div class="row">
            <div class="column-left">
                <h2>Publishers</h2>
                <?php foreach ($publishers as $publisher) : ?>
                    <ul>
                        <li>
                            <a href="?publisher_id=<?php echo $publisher['publisherID']; ?>">
                                <?php echo $publisher['publisherName']; ?>
                            </a>
                        </li>
                    </ul>
                <?php endforeach; ?>
            </div>
            <div class="column-right">
                <h2><?php echo $publisher_name; ?></h2>
                <table>
                    <tr>
                        <th>ISBN</th>
                        <th>Book Title</th>
                        <th>Book Price</th>
                        <th>Delete</th>
                    </tr>
                    <?php foreach ($books as $book) : ?>
                        <tr>
                            <td><?php echo $book['isbn']; ?></td>
                            <td><?php echo $book['bookTitle']; ?></td>
                            <td><?php echo $book['bookPrice']; ?></td>
                            <td>
                                <form action="." method="post">
                                    <input type="hidden" name="action"
                                           value="delete_book" />
                                    <input type="hidden" name="book_id" 
                                           value="<?php echo $book['bookID']; ?>" />
                                    <input type="hidden" name="publisher_id" 
                                           value="<?php echo $book['publisherID']; ?>" />
                                    <input type="submit" value="Delete" />
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <p><a href="?action=add_book_page">Add Product</a></p>
            </div>
        </div>
        <p style="clear:both;padding:30px;"><a href="../index.php">Back to home page</a></p>
    </body>
</html>

