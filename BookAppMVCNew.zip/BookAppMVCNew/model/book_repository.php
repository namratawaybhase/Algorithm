<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function get_books() {
    global $db;
    $query = 'SELECT * FROM books OREDER BY bookID';
    $books = $db->query($query);
    return $books;
}

function get_books_by_publisher($publisher_id) {
    global $db;
    $query = "SELECT * FROM books WHERE publisherID = $publisher_id ORDER BY isbn";
    $books = $db->query($query);
    return $books;
}

function get_book($book_id) {
    global $db;
    $query = "SELECT * FROM books WHERE bookID = $book_id";
    $book = $db->query($query);
    $book = $book->fetch();
    return $book;
}

function delete_book($book_id) {
    global $db;
    $query = "DELETE FROM books WHERE bookID = $book_id";
    $db->exec($query);
}

function add_book($publisher_id, $isbn, $title, $price) {
    global $db;
    $query = "INSERT INTO books
        (publisherID, isbn, bookTitle, bookPrice)
        VALUES
        ('$publisher_id', '$isbn', '$title', '$price')";
    $db->exec($query);
}

?>

